<?php

use App\Models\Admin\Currency;
use App\Models\Link;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

function checkexpire($id){

    $link=Link::where('id',$id)->first();

    $total= $link->created_at->addDays($link->expire_day);
    $now= Carbon::now();
    
    $date= $total->diffInDays($now);
    

    if($total<$now ){
return 'Expired';
    }
    else{
        return $date;
    }
    
}


function convert($price){
    if (Session::has('currency'))
            {
                $curr= Currency::find(Session::get('currency'));

            }
            else
            {
                $curr=  Currency::where('is_default','=',1)->first();

            }
    $price = $price*$curr->value;
    $price=number_format($price,2);
    $price=str_replace(',','',$price);
    return $price;
}
