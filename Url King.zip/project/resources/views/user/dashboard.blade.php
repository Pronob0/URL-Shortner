@extends('layouts.user')

@push('css')

@endpush

@section('content')

<!-- User Dashboard -->


    <article class="main--content">
        <div class="dashboard-header position-relative">
    <div class="bg--gradient">&nbsp;</div>

    @includeIf('partials.user.top-nav')

    <div class="breadcrumb-area">
        <h3 class="title text--white">@lang('Dashboard')</h3>
        <ul class="breadcrumb">
            <li>
                <a href="user-dashboard.html">@lang('Dashboard')</a>
            </li>
            <li>
                @lang('Dashboard')
            </li>
        </ul>
    </div>
</div>
        <div class="dashborad--content">
            <div class="dashboard--content-item">
                <div class="dashboard--wrapper">
                    <div class="dashboard--width">
                        <div class="dashboard-card">
                            <div class="dashboard-card__header">
                                <div class="dashboard-card__header__icon">
                                    <i class="fas fa-wallet"></i>
                                </div>
                                <div class="dashboard-card__header__cont">
                                    <h4 class="name">{{ convert(Auth::user()->amount) }} {{ $curr->sign }}</h4>
                                    <div class="balance">@lang('Total Balance')</div>
                                </div>
                            </div>
                            <div class="dashboard-card__content">
                                <h6 class="m-0">
                                    <a href="deposit-history.html" class="btn btn--base btn-sm w-100">@lang('View Transaction
                                        Log')</a>
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="dashboard--width">
                        <div class="dashboard-card">
                            <div class="dashboard-card__header">
                                <div class="dashboard-card__header__icon">
                                    <i class="fas fa-wallet"></i>
                                </div>
                                <div class="dashboard-card__header__cont">
                                    <h4 class="name">{{ $subscription->title }}</h4>
                                    <div class="balance">@lang('Current Plan')</div>
                                </div>
                            </div>
                            <div class="dashboard-card__content">
                                <h6 class="m-0">
                                    <a href="{{ route('user.plan.log') }}" class="btn btn--base btn-sm w-100">@lang('View Plan
                                        Log')</a>
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="dashboard--width">
                        <div class="dashboard-card">
                            <div class="dashboard-card__header">
                                <div class="dashboard-card__header__icon">
                                    <i class="fas fa-wallet"></i>
                                </div>
                                <div class="dashboard-card__header__cont">
                                    <h4 class="name">{{ $links->count() }}</h4>
                                    <div class="balance">@lang('Total Shorten')</div>
                                </div>
                            </div>
                            <div class="dashboard-card__content">
                                <h6 class="m-0">
                                    <a href="{{ route('all.short.link') }}" class="btn btn--base btn-sm w-100">@lang('View All
                                        Link')</a>
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="dashboard--width">
                        <div class="dashboard-card">
                            <div class="dashboard-card__header">
                                <div class="dashboard-card__header__icon">
                                    <i class="fas fa-wallet"></i>
                                </div>
                                <div class="dashboard-card__header__cont">
                                    <h4 class="name">{{ $subscription->allowed_url-$links->count() }}</h4>
                                    <div class="balance">@lang('Remaining Shorten')</div>
                                </div>
                            </div>
                            <div class="dashboard-card__content">
                                <h6 class="m-0">
                                    <a href="{{ route('front.index') }}" class="btn btn--base btn-sm w-100">@lang('Create Link')</a>
                                </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="dashboard--content-item">
                <h5 class="dashboard-title">@lang('Transactions')</h5>
                <div class="table-responsive table--mobile-lg">
                    <table class="table bg--body">
                        <thead>
                            <tr>
                                <th>@lang('Date')</th>
                                <th>@lang('Transaction ID')</th>
                                <th>@lang('Details')</th>
                                <th>@lang('Amount')</th>
                                <th>@lang('Currency')</th>
                                <th>@lang('Method')</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($transactions as $transaction)
                                <tr>
                                    <td>{{ $transaction->created_at->format('m-d-Y') }}</td>
                                    <td>{{ $transaction->txn_number}}</td>
                                    <td>{{ $transaction->details }}</td>
                                    <td class="{{ $transaction->type =='plus' ? 'text-primary' : 'text-danger' }}">{{ $transaction->type =='plus' ? '+' : '-' }}{{ $transaction->amount*$transaction->currency_value }}</td>
                                    <td>{{ $transaction->currency_code }}</td>
                                    <td>{{ $transaction->method }}</td>
                                </tr>
                   @endforeach
                           
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="footer-copyright text-center mt-auto">
                {!! $gs->copyright !!}
            </div>
        </div>
    </article>

<!-- User Dashboard -->


@endsection

@push('js')

@endpush
