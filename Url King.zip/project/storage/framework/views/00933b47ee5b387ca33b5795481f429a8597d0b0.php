

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<!-- Banner -->
<section class="hero-section inner-hero">
    <div class="container">
      <div class="inner-hero-text">
        <h2 class="title"><?php echo app('translator')->get('FAQ'); ?></h2>
        <ul class="breadcrumb">
          <li>
            <a href="index.html"><?php echo app('translator')->get('Home'); ?></a>
          </li>
          <li>
            <?php echo app('translator')->get('Faq'); ?>
          </li>
        </ul>
      </div>
    </div>
  </section>
  <!-- Banner -->
 

  <section class="pb-100 faqs-section mt-5 ">
    <div class="container">
        
        <div class="accordion-wrapper">

           <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

           <div class="accordion-item <?php echo e($loop->first ? 'active' : ''); ?>  open">
            <div class="accordion-title">
                <h5 class="title">
                   <?php echo e($faq->title); ?>

                </h5>
                <span class="right-icon"></span>
            </div>
            <div class="accordion-content">
                <p>
                    <?php echo $faq->details; ?>

                    
                </p>
                
            </div>
        </div>       
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
            
           
        </div>
    </div>
</section>



<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/front/faq.blade.php ENDPATH**/ ?>