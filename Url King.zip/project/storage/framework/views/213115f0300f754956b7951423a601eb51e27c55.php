

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<article class="main--content">
    <div class="dashboard-header position-relative">
<div class="bg--gradient">&nbsp;</div>
<?php if ($__env->exists('partials.user.top-nav')) echo $__env->make('partials.user.top-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="breadcrumb-area">
    <h3 class="title text--white"><?php echo app('translator')->get('Deposit History'); ?></h3>
    <ul class="breadcrumb">
        <li>
            <a href="<?php echo e(route('user.dashboard')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a>
        </li>
        <li>
            <?php echo app('translator')->get('Deposit History'); ?>
        </li>
    </ul>
</div>
</div>
<div class="dashborad--content">
    <div class="dashboard--content-item">
        <h5 class="dashboard-title"><?php echo app('translator')->get('Deposit History'); ?></h5>
        <div class="table-responsive table--mobile-lg">
            <table class="table bg--body">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('Date'); ?></th>
                        <th><?php echo app('translator')->get('Transaction ID'); ?></th>
                        <th><?php echo app('translator')->get('Amount'); ?></th>
                        <th><?php echo app('translator')->get('Currency'); ?></th>
                        <th><?php echo app('translator')->get('Method'); ?></th>
                    </tr>
                </thead>
                <tbody>
                   
                    <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      
                        <td><?php echo e($deposit->created_at->format('m-d-Y')); ?></td>
                        <td><?php echo e($deposit->txnid); ?></td>
                       
                        <td><?php echo e($deposit->amount*$deposit->currency_value); ?></td>
                        <td><?php echo e($deposit->currency_code); ?></td>
                        <td><?php echo e($deposit->method); ?></td>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
            </table>
           
        </div>
        <?php echo e($deposits->links()); ?>

    </div>
    <div class="footer-copyright text-center mt-auto">
        <?php echo $gs->copyright; ?>

    </div>
</div>
</article>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/user/deposit-log.blade.php ENDPATH**/ ?>