<?php $__env->startSection('content'); ?>

<div class="card">
  <div class="d-sm-flex align-items-center justify-content-between">
  <h5 class=" mb-0 text-gray-800 pl-3"><?php echo e(__('Social Links')); ?></h5>
  <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
      <li class="breadcrumb-item"><a href="javascript:;"><?php echo e(__('Seo Tools')); ?></a></li>
      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.social.index')); ?>"><?php echo e(__('Social Links')); ?></a></li>
  </ol>
  </div>
</div>
<div class="row justify-content-center mt-3">
  <div class="col-lg-6">
    <div class="card mb-4">
      <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Social Links')); ?></h6>
      </div>
      <div class="card-body">
        <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
        <form class="geniusform" action="<?php echo e(route('admin.social.update.all')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo e(csrf_field()); ?>

            <div class="row mb-2">
              <label class="control-label col-sm-3" for="facebook"><?php echo e(__('Facebook')); ?> *</label>
              <div class="col-sm-6">
                <input class="form-control" name="facebook" id="facebook" placeholder="<?php echo e(__('http://facebook.com/')); ?>" required="" type="text" value="<?php echo e($data->facebook); ?>">
              </div>
              <div class="col-sm-3">
                <label class="switch">
                  <input type="checkbox" name="f_status" value="1" <?php echo e($data->f_status==1?"checked":""); ?>>
                  <span class="slider round"></span>
                </label>
              </div>
            </div>
            <div class="row mb-2">
              <label class="control-label col-sm-3" for="gplus"><?php echo e(__('Google Plus')); ?> *</label>
              <div class="col-sm-6">
                <input class="form-control" name="gplus" id="gplus" placeholder="<?php echo e(__('http://google.com/')); ?>" required="" type="text" value="<?php echo e($data->gplus); ?>">
              </div>
              <div class="col-sm-3">
                <label class="switch">
                  <input type="checkbox" name="g_status" value="1" <?php echo e($data->g_status==1?"checked":""); ?>>
                  <span class="slider round"></span>
                </label>
              </div>
            </div>
            <div class="row mb-2">
              <label class="control-label col-sm-3" for="twitter"><?php echo e(__('Twitter')); ?> *</label>
              <div class="col-sm-6">
                <input class="form-control" name="twitter" id="twitter" placeholder="<?php echo e(__('http://twitter.com/')); ?>" required="" type="text" value="<?php echo e($data->twitter); ?>">
              </div>
              <div class="col-sm-3">
                <label class="switch">
                  <input type="checkbox" name="t_status" value="1" <?php echo e($data->t_status==1?"checked":""); ?>>
                  <span class="slider round"></span>
                </label>
              </div>
            </div>
            <div class="row mb-2">
              <label class="control-label col-sm-3" for="linkedin"><?php echo e(__('Linkedin')); ?> *</label>
              <div class="col-sm-6">
                <input class="form-control" name="linkedin" id="linkedin" placeholder="<?php echo e(__('http://linkedin.com/')); ?>" required="" type="text" value="<?php echo e($data->linkedin); ?>">
              </div>
              <div class="col-sm-3">
                <label class="switch">
                  <input type="checkbox" name="l_status" value="1" <?php echo e($data->l_status==1?"checked":""); ?>>
                  <span class="slider round"></span>
                </label>
              </div>
            </div>
            <button type="submit" id="submit-btn" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/admin/socialsetting/index.blade.php ENDPATH**/ ?>