<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <title><?php echo e($gs->title); ?></title>

  <!-- CSS Files  -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/bootstrap.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/animate.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/all.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/lightbox.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/odometer.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/owl.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/main.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/toastr.min.css')); ?>" />
  

  <!-- Favicon -->
  <link rel="shortcut icon" href="<?php echo e(asset('assets/front/images/favicon.png')); ?>" type="image/x-icon" />

  <?php echo $__env->yieldPushContent('css'); ?>

</head>

<body>
  <!-- Overlay Loader & ScrollToTop Button -->
  <span class="toTopBtn">
    <i class="fas fa-angle-up"></i>
  </span>
  <div class="overlay"></div>
  <div class="loader"></div>
  <!-- Overlay Loader & ScrollToTop Button -->
<!-- Header -->
<section class="shorted-link-section">
    <div class="shorted-link-header">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <div class="logo">
                <a href="<?php echo e(route('front.index')); ?>">
                    <img src="<?php echo e(asset('assets/front/images/logo/logo.png')); ?>" alt="logo">
                </a>
            </div>
            <input type="hidden" value="<?php echo e($gs->ad_timeset); ?>" id="timeset">
            <input type="hidden" value="<?php echo e($ads->id); ?>" name="addex" id="addid">
            <div class="header-buttons d-none" id="continue">
                <a href="<?php echo e(route('add.redirect',[$ads->id,$link->alias])); ?>" class="cmn--btn btn-outline"><?php echo app('translator')->get('Skip Add'); ?></a>
            </div>
            <div id="wait">
                <button class="skip-buttons"><?php echo app('translator')->get('Skip Add In'); ?>  <span id="countdown"><?php echo e($gs->ad_timeset); ?></span>S</button>
            </div>
        </div>

    </div>
</div>
    
<div class="shorted-link-wrapper">
    <iframe src="<?php echo e($ads->ad_url); ?>" id="" frameborder="0" ></iframe>
</div>
</section>



<!-- JS Files -->
<script src="<?php echo e(asset('assets/front/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/viewport.jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/odometer.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/lightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/owl.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/custom.js')); ?>" ></script>
<script src="<?php echo e(asset('assets/front/js/toastr.min.js')); ?>"></script>
  <?php echo Toastr::message(); ?>


  
<script>
    $(window).on('load', function () {
        setTimeout(() => {
            $('.shorted-link-wrapper iframe').fadeIn(500)
        }, 500);
    })

    let mainurl = '<?php echo e(url('/')); ?>';
     var loader = <?php echo e($gs->is_loader); ?>;
     var gs      = <?php echo json_encode(DB::table('generalsettings')->where('id','=',1)->first(['is_cookie'])); ?>;


var countdown=$('#timeset').val();
function counter() {
				countdown -= 1;

			    $('#countdown').html(countdown);

				if (countdown <= 0) {
					$('#continue').removeClass('d-none');
					$('#wait').addClass('d-none');
					clearInterval(t);
				}
			}
            $(document).ready(function() {
				t = setInterval("counter()", 1000);
			});





</script>
<?php echo $__env->yieldPushContent('js'); ?>


</body>

</html>
<?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/front/advertise.blade.php ENDPATH**/ ?>