<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <title>URL Shortner</title>

  <!-- CSS Files  -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/bootstrap.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/animate.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/all.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/lightbox.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/odometer.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/owl.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/main.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/toastr.min.css')); ?>" />

  <!-- Favicon -->
  <link rel="shortcut icon" href="<?php echo e(asset('assets/front/images/favicon.png')); ?>" type="image/x-icon" />

  <?php echo $__env->yieldPushContent('css'); ?>

</head>

<body>
  <!-- Overlay Loader & ScrollToTop Button -->
  <span class="toTopBtn">
    <i class="fas fa-angle-up"></i>
  </span>
  <div class="overlay"></div>
  <div class="loader"></div>
  <!-- Overlay Loader & ScrollToTop Button -->
<!-- Header -->

<!-- Header -->
<!-- Hero -->

<main class="dashboard-section">

    <?php if ($__env->exists('partials.user.sidebar')) echo $__env->make('partials.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>
</main>
<!-- JS Files -->
<script src="<?php echo e(asset('assets/front/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/bootstrap.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/viewport.jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/odometer.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/lightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/owl.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/custom.js')); ?>" ></script>
<script src="<?php echo e(asset('assets/front/js/toastr.min.js')); ?>"></script>
<?php echo Toastr::message(); ?>

<script>
    let mainurl = '<?php echo e(url('/')); ?>';
     var loader = <?php echo e($gs->is_loader); ?>;
     var gs      = <?php echo json_encode(DB::table('generalsettings')->where('id','=',1)->first(['is_cookie'])); ?>;

</script>
<?php echo $__env->yieldPushContent('js'); ?>


</body>

</html>
<?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/layouts/user.blade.php ENDPATH**/ ?>