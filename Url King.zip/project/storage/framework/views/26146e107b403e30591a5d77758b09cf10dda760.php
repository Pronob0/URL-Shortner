<div class="alert alert-danger alert-dismissible fade show" role="alert" style="display: none;">

    <button type="button" class="btn-close close" data-bs-dismiss="alert" aria-label="Close">&times;</button>
    <p class="m-0"></p>
  </div>


<div class="alert alert-success alert-dismissible fade show" role="alert" style="display: none;">
    <p class="m-0"></p>
    <button type="button" class="btn-close close" data-bs-dismiss="alert" aria-label="Close">&times;</button>
  </div>
<?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/alerts/form-both.blade.php ENDPATH**/ ?>