<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="hero-section inner-hero">
   <div class="container">
      <div class="inner-hero-text">
         <h2 class="title"><?php echo app('translator')->get('Pricing Plan'); ?></h2>
         <ul class="breadcrumb">
            <li>
               <a href="index.html"><?php echo app('translator')->get('Home'); ?></a>
            </li>
            <li>
               <?php echo app('translator')->get('Pricing Plan'); ?>
            </li>
         </ul>
      </div>
   </div>
</section>
<section class="pricing-section pb-100 pt-100">
   <div class="container">
      <div class="section-title text-center">
         <h2 class="title"><?php echo e($ps->pricing_title); ?></h2>
         <p>
            <?php echo $ps->pricing_text; ?>

         </p>
      </div>
      <div class="row g-3 g-md-4 justify-content-center">

        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <div class="col-sm-6 col-lg-4 col-xl-3">
            <div class="pricing-card">
               <div class="pricing-card__top">
                  <div>
                     <?php echo e($plan->title); ?>

                  </div>
                  <h4 class="price"><?php echo e($plan->planprice()); ?><sub> / <?php echo e($plan->days); ?> <?php echo app('translator')->get('days'); ?></sub></h4>
               </div>
               <div class="pricing-card__bottom">
                  <ul>
                     <li>
                         <?php if($plan->free==1): ?>
                         <i class="fas fa-check"></i> <?php echo e(('Free Advertisement')); ?>

                         <?php else: ?>
                         <i class="fas fa-times " style="color:rgb(216, 32, 32)"></i> <?php echo e(('Free Advertisement')); ?>

                         <?php endif; ?>

                     </li>
                     <li>
                        <i class="fas fa-check"></i> <?php echo e($plan->allowed_url); ?> - <?php echo app('translator')->get('Short Links '); ?>
                     </li>
                     <li>
                        <i class="fas fa-check"></i><?php echo e($plan->click_limit); ?> - <?php echo app('translator')->get('Redirect Limit'); ?>
                     </li>
                     <li>
                        <i class="fas fa-check"></i> <?php echo app('translator')->get('Custom Aliases'); ?>
                     </li>
                     <li>
                        <i class="fas fa-check"></i> <?php echo e($plan->days); ?> - <?php echo app('translator')->get('Days validity'); ?>
                     </li>
                     <li>
                        <i class="fas fa-check"></i><?php echo app('translator')->get('Price'); ?> - <?php echo e(round($plan->price,2)); ?>

                     </li>
                  </ul>

                  <?php if(Auth::user()): ?>
                  <?php if(DB::table('user_subscriptions')->where('user_id',Auth::user()->id)->where('status',1)->first()->subscription_id==$plan->id): ?>
                <a href="<?php echo e(route('user.subscription',$plan->slug)); ?>" class="cmn--btn w-100"><?php echo app('translator')->get('Activated'); ?></a>

                    <?php else: ?>
                   <a href="<?php echo e(route('user.subscription',$plan->slug)); ?>" class="cmn--btn w-100"><?php echo app('translator')->get('Active Now'); ?></a>
                   <?php endif; ?>
                    <?php else: ?>
                  <a href="<?php echo e(route('user.loginform')); ?>" class="cmn--btn w-100"><?php echo app('translator')->get('Activate Now'); ?></a>
                    <?php endif; ?>

               </div>
            </div>
         </div>

         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/user/package/index.blade.php ENDPATH**/ ?>