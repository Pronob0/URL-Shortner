<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="d-sm-flex align-items-center justify-content-between">
    <h5 class=" mb-0 text-gray-800 pl-3"><?php echo e(__('Pricing Section')); ?></h5>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
        <li class="breadcrumb-item"><a href="javascript:;"><?php echo e(__('Home Page Setting')); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.ps.pricing')); ?>"><?php echo e(__('Pricing Section')); ?></a></li>
    </ol>
    </div>
</div>

<div class="row justify-content-center mt-3">
  <div class="col-lg-6">
    <!-- Form Basic -->
    <div class="card mb-4">
      <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Pricing Section')); ?></h6>
      </div>

      <div class="card-body">
        <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
        <form class="geniusform" action="<?php echo e(route('admin.ps.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo e(csrf_field()); ?>




            <div class="form-group">
                <label for="title"><?php echo e(__('Pricing Section Title')); ?> *</label>
                <input type="text" class="form-control" id="title" name="pricing_title"  placeholder="<?php echo e(__('Pricing Title')); ?>" value="<?php echo e($ps->pricing_title); ?>" required>
            </div>

            <div class="form-group">
              <label for="text"><?php echo e(__('Pricing Section Text')); ?> *</label>
              <textarea name="pricing_text" id="text" cols="30" rows="5" class="form-control" placeholder="<?php echo e(__('Pricing Text')); ?>" required><?php echo e($ps->pricing_text); ?> </textarea>
            </div>

            <button type="submit" id="submit-btn" class="btn btn-primary btn-block"><?php echo e(__('Submit')); ?></button>

        </form>
      </div>
    </div>

    <!-- Form Sizing -->

    <!-- Horizontal Form -->

  </div>

</div>
<!--Row-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/admin/pagesetting/pricing.blade.php ENDPATH**/ ?>