

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<article class="main--content">
    <div class="dashboard-header position-relative">
<div class="bg--gradient">&nbsp;</div>

<?php if ($__env->exists('partials.user.top-nav')) echo $__env->make('partials.user.top-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="breadcrumb-area">
    <h3 class="title text--white"><?php echo app('translator')->get('Edit Link'); ?></h3>
    <ul class="breadcrumb">
        <li>
            <a href="user-dashboard.html"><?php echo app('translator')->get('Dashboard'); ?></a>
        </li>
        <li>
            <?php echo app('translator')->get('Edit Link'); ?>
        </li>
    </ul>
</div>
</div>

<div class="dashborad--content">
    <div class="dashboard--content-item pt-5">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7 col-xxl-6">
                <div class="profile--card">
                    <form id="userform" action="<?php echo e(route('user.link.store',$link->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row gy-4">
                            <div class="col-sm-12">
                                <label for="alias" class="form-label"><?php echo app('translator')->get('Alias'); ?></label>
                                <input type="text" id="alias"
                                    class="form-control form--control bg--white" name="alias" placeholder="Enter Custom Alias" required="" value="<?php echo e($link->alias); ?>">
                            </div>
                            <div class="col-sm-12">
                                <label for="meta_title" class="form-label"><?php echo app('translator')->get('Meta Title'); ?></label>
                                <input type="meta_title" id="meta_title" name="meta_title" value="<?php echo e($link->meta_title); ?>"
                                    class="form-control form--control bg--white" placeholder="<?php echo app('translator')->get('Enter Meta Title'); ?>">
                            </div>
                            <div class="col-sm-12">
                                <label for="meta_description" class="form-label"><?php echo app('translator')->get('Meta Description'); ?></label>
                                <input type="confirm-password" id="meta_description" name="meta_description" value="<?php echo e($link->meta_description); ?>"
                                    class="form-control form--control bg--white" placeholder="<?php echo app('translator')->get('Meta Description'); ?>">
                            </div>
                            <div class="col-sm-12">
                                <div class="text-end">
                                    <button type="submit" class="cmn--btn"><?php echo app('translator')->get('Update'); ?></button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-copyright text-center mt-auto">
        <?php echo $gs->copyright; ?>

    </div>
</div>

</article>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/user/link/edit.blade.php ENDPATH**/ ?>