<div class="alert alert-success alert-dismissible" style="display: none;">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <p class="m-0"></p>
    </div>



      <div class="alert alert-danger alert-dismissible" style="display: none;" role="alert">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <p class="m-0"></p>
        </div>

<?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/includes/admin/form-login.blade.php ENDPATH**/ ?>