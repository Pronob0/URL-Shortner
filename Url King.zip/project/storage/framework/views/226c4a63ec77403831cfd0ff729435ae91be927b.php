<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo e(__('Dashboard')); ?></h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    </ol>
  </div>
  <?php if(Session::has('cache')): ?>

  <div class="alert alert-success validation">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
              aria-hidden="true">×</span></button>
      <h3 class="text-center"><?php echo e(Session::get("cache")); ?></h3>
  </div>


<?php endif; ?>

  <div class="row mb-3">

    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card h-100">
        <div class="card-body">
          <div class="row align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-uppercase mb-1"><?php echo e(__('Active Users')); ?></div>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(\DB::table('users')->where('ban',0)->count()); ?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-user fa-2x text-success"></i>
            </div>
          </div>
        </div>
      </div>
    </div> 
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-uppercase mb-1"><?php echo e(__('Blocked Users')); ?></div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(\DB::table('users')->where('ban',1)->count()); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-user fa-2x text-danger"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
       <div class="col-xl-3 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-uppercase mb-1"><?php echo e(__('Total Users')); ?></div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(\DB::table('users')->count()); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-user-tie fa-2x text-primary"></i>
              </div>
            </div>
          </div>
        </div>
      </div> 
       <div class="col-xl-3 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-uppercase mb-1"><?php echo e(__('Total Links')); ?></div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(\DB::table('links')->where('status',0)->count()); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-file fa-2x text-success"></i>
              </div>
            </div>
          </div>
        </div>
      </div> 
       <div class="col-xl-3 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-uppercase mb-1"><?php echo e(__('Total Advertisement')); ?></div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(\DB::table('advertisements')->where('status',0)->count()); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-file fa-2x text-primary"></i>
              </div>
            </div>
          </div>
        </div>
      </div> 
       <div class="col-xl-3 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-uppercase mb-1"><?php echo e(__('Deactive Links')); ?></div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(\DB::table('links')->where('status',1)->count()); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-file fa-2x text-warning"></i>
              </div>
            </div>
          </div>
        </div>
      </div> 
      <div class="col-xl-3 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-uppercase mb-1"><?php echo e(__('Total Advertisement profit given')); ?></div>
                <div class="h6 mb-0 mt-2 font-weight-bold text-gray-800"><i class='fas fa-dollar-sign'></i> <?php echo e(\DB::table('advertisements')->sum('expression')*$gs->ad_reward); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-money-check-alt fa-2x text-success"></i>
              </div>
            </div>
          </div>
        </div>
      </div> 
        <div class="col-xl-3 col-md-6 mb-4">
        <div class="card h-100">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-uppercase mb-1"><?php echo e(__('Pending Withdraw Request')); ?></div>
                <div class="h6 mb-0 mt-2 font-weight-bold text-gray-800"> <?php echo e(\DB::table('withdraws')->where('status','pending')->count()); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-money-check-alt fa-2x text-success"></i>
              </div>
            </div>
          </div>
        </div>
      </div>  

    

       <div class="col-xl-12 col-md-12 mt-5 mb-5">
        <h5 class=" mb-3 text-gray-800"><?php echo e(__('Top visited link')); ?></h5>
        <div class="card h-100">
          <div class="card-body">
              <table class="table  table-striped ">
                <thead class="thead-dark">
                    <tr>
                      <th ><?php echo app('translator')->get('SL'); ?></th>
                      <th ><?php echo app('translator')->get('User Name'); ?></th>
                      <th class="w-25"><?php echo app('translator')->get('Email'); ?></th>
                      <th ><?php echo app('translator')->get('Link'); ?></th>
                      <th ><?php echo app('translator')->get('Visited'); ?></th>

                    </tr>
                  </thead>
                  <tbody>

                      <?php $__currentLoopData = DB::table('links')->orderBy('click','DESC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php
                          $user=DB::table('users')->where('id',$link->user_id)->first()
                      ?>

                      <tr>
                        <th><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($user->username); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e(url('/'.$link->alias)); ?></td>
                        <td><?php echo e($link->click); ?></td>
                      </tr>
                     
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
          </div>
        </div>
      </div> 




  </div>
  <!--Row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\newfolder\main_file\project\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>