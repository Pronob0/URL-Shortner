<?php $__env->startSection('content'); ?>
<div class="content-area">
   <div class="card">
      <div class="d-sm-flex align-items-center justify-content-between">
         <h5 class=" mb-0 text-gray-800 pl-3"><?php echo e(__('Edit Template')); ?> <a class="btn btn-primary btn-rounded btn-sm" href="<?php echo e(url()->previous()); ?>"><i class="fas fa-arrow-left"></i> <?php echo e(__("Back")); ?></a></h5>
         <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
            <li class="breadcrumb-item"><a href="javascript:;"><?php echo e(__('Email Settings')); ?></a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.mail.edit',$data->id)); ?>"><?php echo e(__('Edit Template')); ?></a></li>
         </ol>
      </div>
   </div>
</div>
<div class="row justify-content-center mt-3">
   <div class="col-lg-10">
      <!-- Form Basic -->
      <div class="card mb-4">
         <div class="card-header py-3 text-center">
            <div class="row" >
               <div class="col-lg-12 offset-lg-4 col-md-12 offset-md-4">
                  <p><?php echo e(__('Use the BB codes, it show the data dynamically in your emails.')); ?></p>
                  <br>
                  <table class="table table-bordered">
                     <thead>
                        <tr>
                           <th><?php echo e(__('Meaning')); ?></th>
                           <th><?php echo e(__('BB Code')); ?></th>
                        </tr>
                     </thead>
                     <tbody>
                        <tr>
                           <td><?php echo e(__('Customer Name')); ?></td>
                           <td>{customer_name}</td>
                        </tr>
                        <tr>
                           <td><?php echo e(__('Order Amount')); ?></td>
                           <td>{order_amount}</td>
                        </tr>
                        <tr>
                           <td><?php echo e(('Admin Name')); ?></td>
                           <td>{admin_name}</td>
                        </tr>
                        <tr>
                           <td><?php echo e(__('Admin Email')); ?></td>
                           <td>{admin_email}</td>
                        </tr>
                        <tr>
                           <td><?php echo e(__('Website Title')); ?></td>
                           <td>{website_title}</td>
                        </tr>
                        <tr>
                           <td><?php echo e(__('Order Number')); ?></td>
                           <td>{order_number}</td>
                        </tr>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         <div class="card-body">
            <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
            <form action="<?php echo e(route('admin.mail.update',$data->id)); ?>" method="POST" enctype="multipart/form-data">
               <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               <?php echo e(csrf_field()); ?>

               <div class="form-group">
                  <label><?php echo e(__('Email Type')); ?> *</label>
                  <input type="text" class="input-field" placeholder="<?php echo e(__('Email Type')); ?>" required="" value="<?php echo e($data->email_type); ?>" disabled="">
               </div>
               <div class="form-group">
                  <label><?php echo e(__('Email Subject')); ?> *</label>
                  <small><?php echo e(__('(In Any Language)')); ?></small>
                  <input type="text" class="input-field" name="email_subject" placeholder="<?php echo e(__('Email Subject')); ?>" required="" value="<?php echo e($data->email_subject); ?>">
               </div>
               <div class="form-group">
                  <label><?php echo e(__('Email Body')); ?> *</label>
                  <small><?php echo e(__('(In Any Language)')); ?></small>
                  <textarea class="form-control summernote" name="email_body" placeholder="<?php echo e(__('Email Body')); ?>"><?php echo e($data->email_body); ?></textarea>
               </div>
               <button type="submit"  class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
            </form>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\newfolder\main_file\project\resources\views/admin/email/edit.blade.php ENDPATH**/ ?>