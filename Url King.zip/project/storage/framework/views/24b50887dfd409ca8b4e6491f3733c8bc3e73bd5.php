<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- Banner -->
<section class="hero-section inner-hero">
    <div class="container">
      <div class="inner-hero-text">
        <h2 class="title"><?php echo app('translator')->get('Registration'); ?></h2>
        <ul class="breadcrumb">
          <li>
            <a href="index.html"><?php echo app('translator')->get('Home'); ?></a>
          </li>
          <li>
            <?php echo app('translator')->get('Registration'); ?>
          </li>
        </ul>
      </div>
    </div>
  </section>
  <!-- Banner -->
  <!-- Account -->
  <section class="account-section pt-100 pb-100">
      <div class="container">
          <div class="account-wrapper bg--section">
              <div class="section-title mb-3">
                  <h6 class="subtitle mb-3 text--base"><?php echo app('translator')->get('Sign Up'); ?></h6>
                  <h3 class="title"><?php echo app('translator')->get('Create Account Now'); ?></h3>
              </div>
              <form class="account-form row gy-3 gx-4 align-items-center" id="registerform" action="<?php echo e(route('user.register.submit')); ?>" method="POST">
                <?php if ($__env->exists('alerts.form-both')) echo $__env->make('alerts.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php echo csrf_field(); ?>
                  <div class="col-sm-6">
                      <label for="name" class="form-label"><?php echo app('translator')->get('Your Name'); ?></label>
                      <input type="text" id="name" name="name" class="form-control form--control">
                  </div>

                  <div class="col-sm-6">
                      <label for="email" class="form-label"><?php echo app('translator')->get('Your Email'); ?></label>
                      <input type="text" id="email" name="email" class="form-control form--control">
                  </div>

                  <div class="col-sm-6">
                    <label class="form-label"><?php echo app('translator')->get('Country'); ?></label>
                    <select required="" class="form-control form--control" id="country" name="country">
                        <option value=""><?php echo app('translator')->get('Select Country'); ?></option>
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($contry->phone_code); ?>"><?php echo e($contry->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                 </div>

                  <div class="col-sm-6">
                    <label for="phone" class="form-label"><?php echo app('translator')->get('Your Phone'); ?></label>
                    <div class="input-group ">
                        <div class="input-group-prepend">
                          <span class="input-group-text"  id="phone_code">00</span>
                        </div>
                        <input type="text" id="phone" name="phone" required="" class="form-control form--control"  aria-label="Phone" aria-describedby="phone_code">
                      </div>
                  </div>

                  <div class="col-sm-6">
                      <label for="password" class="form-label"><?php echo app('translator')->get('Your Password'); ?></label>
                      <input type="password" id="password" name="password" required="" class="form-control form--control">
                  </div>

                  <div class="col-sm-6">
                      <label for="confirm-password" class="form-label"><?php echo app('translator')->get('Confirm Password'); ?></label>
                      <input type="password" id="confirm-password" name="password_confirmation"
                          class="form-control form--control" required="">
                  </div>

                  <?php if($gs->is_capcha == 1): ?>
                  <div class="form-group<?php echo e($errors->has('g-recaptcha-response') ? ' has-error' : ''); ?>">
                    <label class="col-sm-6 control-label"><?php echo app('translator')->get('Captcha'); ?></label>
                    <div class="col-sm-6">
                        <?php echo NoCaptcha::renderJs(); ?>

                        <?php echo app('captcha')->display(); ?>

                        <?php if($errors->has('g-recaptcha-response')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                  <?php endif; ?>

                    <input class="mprocessdata" type="hidden" value="<?php echo e((('Processing...'))); ?>">
                  <div class="col-sm-12 d-flex flex-wrap justify-content-between align-items-center">
                      <button type="submit" id="btn" class="cmn--btn bg--base me-3 btn">
                          <?php echo app('translator')->get('Register Now'); ?>
                      </button>
                      <div class="text-end">
                          <a href="<?php echo e(route('user.loginform')); ?>" class="text--base"><?php echo app('translator')->get('Already have
                              an account ?'); ?></a>
                      </div>
                  </div>
                  
              </form>
          </div>
      </div>
  </section>
  <!-- Account -->



<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script>
    $(document).on('change','#country',function(){
        var value= $(this).val();
        document.getElementById("phone_code").innerHTML = value;

    })


</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/front/register.blade.php ENDPATH**/ ?>