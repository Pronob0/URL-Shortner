<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="<?php echo e($gs->title); ?>">

  <?php if(isset($page->meta_keywords) && isset($page->meta_description)): ?>
  <meta property="og:title" content="<?php echo e($page->title); ?>" />
  <meta property="og:description" content="<?php echo e($page->meta_description != null ? $page->meta_description : strip_tags($page->meta_description)); ?>" />
	<meta name="keywords" content="<?php echo e($page->meta_keywords); ?>">
	<meta name="description" content="<?php echo e($page->meta_description); ?>">
	<title><?php echo e($gs->title); ?></title>

	<?php elseif(isset($blog->meta_tag) && isset($blog->meta_description)): ?>

		<meta property="og:title" content="<?php echo e($blog->title); ?>" />
		<meta property="og:description" content="<?php echo e($blog->meta_description != null ? $blog->meta_description : strip_tags($blog->meta_description)); ?>" />
		<meta property="og:image" content="<?php echo e(asset('assets/images/blogs/'.$blog->photo)); ?>" />
		<meta name="keywords" content="<?php echo e($blog->meta_tag); ?>">
		<meta name="description" content="<?php echo e($blog->meta_description); ?>">
		<title><?php echo e(substr($blog->title, 0,11)."-"); ?><?php echo e($gs->title); ?></title>

	<?php elseif(isset($link)): ?>

		<meta name="title" content="<?php echo e(!empty($link->meta_title) ?  $link->meta_title : ''); ?>">
		<meta name="description" content="<?php echo e($link->meta_description != null ? $link->meta_description : strip_tags($link->description)); ?>">
		<meta property="og:title" content="<?php echo e($link->meta_title); ?>" />
		<meta property="og:description" content="<?php echo e($link->meta_description != null ? $link->meta_description : strip_tags($link->description)); ?>" />
		<title><?php echo e($gs->title); ?></title>

	<?php else: ?>

		<meta property="og:title" content="<?php echo e($gs->title); ?>" />
		<meta property="og:image" content="<?php echo e(asset('assets/images/'.$gs->logo)); ?>" />
		<meta name="title" content="<?php echo e($seo->meta_title); ?>">
		<meta name="description" content="<?php echo e($seo->meta_description); ?>">
		<meta name="author" content="GeniusOcean">
		<title><?php echo e($gs->title); ?></title>

	<?php endif; ?>

  

  <title><?php echo e($gs->title); ?></title>

  <!-- CSS Files  -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/bootstrap.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/animate.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/all.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/lightbox.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/odometer.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/owl.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/main.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/toastr.min.css')); ?>" />
 
  <?php if(!empty($seo->google_analytics)): ?>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag() {
				dataLayer.push(arguments);
		}
		gtag('js', new Date());
		gtag('config', '<?php echo e($seo->google_analytics); ?>');
	</script>
	<?php endif; ?>

  <?php if($default_font->font_value): ?>
			<link href="https://fonts.googleapis.com/css?family=<?php echo e($default_font->font_value); ?>&display=swap" rel="stylesheet">
		<?php else: ?>
			<link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
		<?php endif; ?>

    <?php if($default_font->font_family): ?>
			<link rel="stylesheet" id="colorr" href="<?php echo e(asset('assets/front/css/font.php?font_familly='.$default_font->font_family)); ?>">
		<?php else: ?>
			<link rel="stylesheet" id="colorr" href="<?php echo e(asset('assets/front/css/font.php?font_familly='."Open Sans")); ?>">
		<?php endif; ?>
  

  <!-- Favicon -->
  <link rel="shortcut icon" href="<?php echo e(asset('assets/front/images/favicon.png')); ?>" type="image/x-icon" />

  <?php echo $__env->yieldPushContent('css'); ?>

</head>

<body>
  <!-- Overlay Loader & ScrollToTop Button -->
  <span class="toTopBtn">
    <i class="fas fa-angle-up"></i>
  </span>
  <div class="overlay"></div>
  <div class="loader"></div>
  <!-- Overlay Loader & ScrollToTop Button -->
<!-- Header -->
<header>
   <?php if ($__env->exists('partials.front.navbar')) echo $__env->make('partials.front.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<!-- Header -->
<!-- Hero -->
<?php echo $__env->yieldContent('content'); ?>

<?php if ($__env->exists('partials.front.linkmanagement')) echo $__env->make('partials.front.linkmanagement', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<footer>
    <?php echo $__env->make('partials.front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<!-- JS Files -->
<script src="<?php echo e(asset('assets/front/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/viewport.jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/odometer.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/lightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/owl.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/front/js/custom.js')); ?>" ></script>
<script src="<?php echo e(asset('assets/front/js/toastr.min.js')); ?>"></script>
  <?php echo Toastr::message(); ?>

<script>
    let mainurl = '<?php echo e(url('/')); ?>';
     var loader = <?php echo e($gs->is_loader); ?>;
     var gs      = <?php echo json_encode(DB::table('generalsettings')->where('id','=',1)->first(['is_cookie'])); ?>;

</script>

<?php echo $__env->yieldPushContent('js'); ?>


</body>

</html>
<?php /**PATH D:\xampp\htdocs\pro-short\newfolder\main_file\project\resources\views/layouts/front.blade.php ENDPATH**/ ?>