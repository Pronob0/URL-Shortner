

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<article class="main--content">
    <div class="dashboard-header position-relative">
<div class="bg--gradient">&nbsp;</div>

<?php if ($__env->exists('partials.user.top-nav')) echo $__env->make('partials.user.top-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="breadcrumb-area">
    <h3 class="title text--white"><?php echo app('translator')->get('Deposit'); ?></h3>
    <ul class="breadcrumb">
        <li>
            <a href="<?php echo e(route('user.dashboard')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a>
        </li>
        <li>
            <?php echo app('translator')->get('Deposit'); ?>
        </li>
    </ul>
</div>
</div>

<div class="dashborad--content">
    <div class="dashboard--content-item">
        <div class="dashboard--wrapper">
            <?php $__currentLoopData = $paymentgateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paydata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="dashboard--width">
                <div class="dashboard-card">
                    <div class="dashboard-card__header">
                        <div class="dashboard-card__header__icon">
                            <i class="fas fa-wallet"></i>
                        </div>
                        <div class="dashboard-card__header__cont">
                            <h4 class="name"><?php echo e($paydata->name); ?></h4>
                            
                        </div>
                    </div>
                    <div class="dashboard-card__content">
                        <div class="deposit-btn-grp">
                          <a   href="javascript:;" data-bs-toggle="modal" data-bs-target="#paymodal" class="deposit btn btn-sm btn--primary"  data-href=" <?php echo e(route('user.withdraw.popup',$paydata->id)); ?> " data-form="<?php echo e($paydata->showDepositLink()); ?>" data-val="<?php echo e($paydata->keyword); ?>"><?php echo app('translator')->get("Deposit"); ?></a>
                        </div>
                    </div>
                    
                </div>
            </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            
        </div>
    </div>
   
    <div class="footer-copyright text-center mt-auto">
       <?php echo $gs->copyright; ?>

    </div>
</div>



<div class="modal fade" id="paymodal" tabindex="-1" role="dialog"
 aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title text-center"><?php echo e(__("Deposit Payment")); ?></h5>
            <button type="button" class="close btn btn--danger" data-bs-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modalLoad">

            </div>
        </div>
    </div>
</div>





</article>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script type="text/javascript" src="<?php echo e(asset('assets/front/js/payvalid.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/front/js/paymin.js')); ?>"></script>
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/front/js/payform.js')); ?>"></script>
<script src="https://secure.mlstatic.com/sdk/javascript/v1/mercadopago.js"></script>
<script src="https://js.paystack.co/v1/inline.js"></script>
<script type="text/javascript">


  
 





(function($) {
		"use strict";
        // var depo=$('.deposit-btn-grp').find('a').attr('id');
        // alert(depo);

        $(document).on('click','.deposit',function(){
         
            var mhref= $(this).attr('data-href');
            var val  = $(this).attr('data-val');
            var form = $(this).attr('data-form');
            

            
            $.get(mhref,function(res){
                $('.modalLoad').html(res);
            

            if(val == 'paystack'){

                $('.modalLoad').find('form').attr('id','paystack');
                $('#amount').prop('name','amount');
                
            }
            else if(val == 'voguepay'){
                $('.modalLoad').find('form').attr('id','voguepay');
                   
                $('#amount').prop('name','amount');
                }
            else if(val == 'mercadopago'){
            $('.modalLoad').find('form').attr('id','mercadopago');
            $('#amount').prop('name','deposit_amount');
            }
            else if(val == '2checkout'){
            $('.modalLoad').find('form').attr('id','twocheckout');
            $('#amount').prop('name','amount');
            }
            else {
            $('.modalLoad').find('form').attr('id','deposit-form');
            $('#amount').prop('name','amount');
                }

                $('.modalLoad').find('form').attr('action',form);

            })
        
        });




$(document).on('submit','#paystack',function(){
            var val = $('#sub').val();
            if(val == 0){
                var total = $('#amount').val();
                total = Math.round(total);
                var handler = PaystackPop.setup({
                key: '<?php echo e($paystack["key"]); ?>',
                email: '<?php echo e(Auth::user()->email); ?>',
                amount: total * 100,
                currency: "<?php echo e($curr->name); ?>",
                ref: ''+Math.floor((Math.random() * 1000000000) + 1),
                    callback: function(response){
                        $('#ref_id').val(response.reference);
                        $('#sub').val('1');
                        $('#final-btn').click();
                    },
                    onClose: function(){
                        window.location.reload();
                    }
                });
                handler.openIframe();
                 return false;

            }
            else {
                return true;
            }
		});




       

})(jQuery);

</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/user/deposit/index.blade.php ENDPATH**/ ?>