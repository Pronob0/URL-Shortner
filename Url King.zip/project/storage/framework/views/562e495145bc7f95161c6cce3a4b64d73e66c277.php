<?php $__env->startSection('content'); ?>


    <div class="card">
        <div class="d-sm-flex align-items-center justify-content-between">
        <h5 class=" mb-0 text-gray-800 pl-3"><?php echo e(__('Withdraw Request')); ?></h5>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>

            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.user.index')); ?>"><?php echo e(__('Withdraw Request')); ?></a></li>
        </ol>
        </div>
    </div>


    <!-- Row -->
    <div class="row mt-3">
      <!-- Datatables -->
      <div class="col-lg-12">

        <?php echo $__env->make('includes.admin.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card mb-4">
          <div class="table-responsive p-3">
            <table id="geniustable" class="table table-hover dt-responsive" cellspacing="0" width="100%">
              <thead class="thead-light">
                <tr>
                    <th><?php echo e(__("Email")); ?></th>
                    <th><?php echo e(__("Phone")); ?></th>
                    <th><?php echo e(__("Amount")); ?></th>
                    <th><?php echo e(__("Method")); ?></th>
                    <th><?php echo e(__("Withdraw Date")); ?></th>
                   
                    <th><?php echo e(__("Actions")); ?></th>
                </tr>
              </thead>
            </table>
          </div>
        </div>
      </div>
      <!-- DataTable with Hover -->

    </div>
    <!--Row-->

    <div class="modal fade confirm-modal" id="details" tabindex="-1" role="dialog"
    aria-labelledby="statusModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title"><?php echo e(__("Withdraw Request Details
            ")); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body">

        </div>
        <div class="modal-footer">
        <a href="javascript:;" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__("Back")); ?></a>
        </div>
    </div>
    </div>
    </div>


    

<div class="modal fade confirm-modal" id="status-modal" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header d-block text-center">
                <h4 class="modal-title d-inline-block"><?php echo e(__("Accpet Withdraw")); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <p class="text-center"><?php echo e(__("You are about to accept this Withdraw.")); ?></p>
                <p class="text-center"><?php echo e(__("Do you want to proceed?")); ?></p>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__("Cancel")); ?></button>
                <a class="btn btn-success btn-ok"><?php echo e(__("Accept")); ?></a>
            </div>

        </div>
    </div>
</div>
<div class="modal fade status-modal" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header d-block text-center">
                <h4 class="modal-title d-inline-block"><?php echo e(__("Reject Withdraw")); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <p class="text-center"><?php echo e(__("You are about to reject this Withdraw.")); ?></p>
                <p class="text-center"><?php echo e(__("Do you want to proceed?")); ?></p>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__("Cancel")); ?></button>
                <a class="btn btn-danger btn-ok"><?php echo e(__("Reject")); ?></a>
            </div>

        </div>
    </div>
</div>






<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">

var table = $('#geniustable').DataTable({
			   ordering: false,
               processing: true,
               serverSide: true,
               searching: false,
               ajax: '<?php echo e(route('admin.withdraw.datatables')); ?>',
               columns: [

                        { data: 'email', name: 'email' },
                        {data:'phone',name: 'phone'},
                        {data:'amount',name:'amount'},
                        {data:'method',name:'method'},
                        {data: 'created_at',name:'created_at'},
            			{ data: 'action', searchable: false, orderable: false }
                     ],
                language : {

                }
            });

            $(document).on('click', '#applicationDetails', function () {
      let detailsUrl = $(this).data('href');
      $.get(detailsUrl, function( data ) {
        $( "#details .modal-body" ).html( data );
      });
    })

    $('.status-modal').on('show.bs.modal', function(e) {
    $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
  });

  $('.status-modal .btn-ok').on('click', function(e) {

  if(admin_loader == 1)
  {
  $('.submit-loader').show();
  }

    $.ajax({
    type:"GET",
    url:$(this).attr('href'),
    success:function(data)
    {
          $('.status-modal').modal('hide');
          table.ajax.reload();
          $('.alert-danger').hide();
          $('.alert-success').show();
          $('.alert-success p').html(data);

          if(admin_loader == 1)
          {
            $('.submit-loader').hide();
          }

    }
    });
    return false;
  });



</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/admin/user/withdraws.blade.php ENDPATH**/ ?>