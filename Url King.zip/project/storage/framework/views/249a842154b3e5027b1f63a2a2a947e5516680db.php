<div class="ctas-section">
    <div class="container">
        <div class="ctas-wrapper">
            <div class="ctas-inner">
                <div class="section-title mb-0 text-center">
                    <h2 class="title"><?php echo app('translator')->get('Link Management Platform'); ?></h2>
                    <div class="btn__grp">
                        <a href="<?php echo e(route('user.loginform')); ?>" class="cmn--btn"><?php echo app('translator')->get('Sign Up'); ?></a>
                        <?php if(Auth::user()): ?>
                        <a href="<?php echo e(route('user.package')); ?>" class="cmn--btn btn-outline"><?php echo app('translator')->get('Pricing'); ?></a>
                        <?php else: ?>
                        <a href="<?php echo e(route('user.loginform')); ?>" class="cmn--btn btn-outline"><?php echo app('translator')->get('Pricing'); ?></a>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/partials/front/linkmanagement.blade.php ENDPATH**/ ?>