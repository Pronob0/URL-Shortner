

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<!-- Banner -->
<section class="hero-section inner-hero">
    <div class="container">
      <div class="inner-hero-text">
        <h2 class="title"><?php echo app('translator')->get('Blog'); ?></h2>
        <ul class="breadcrumb">
          <li>
            <a href="index.html"><?php echo app('translator')->get('Home'); ?></a>
          </li>
          <li>
            <?php echo app('translator')->get('Single Blog'); ?>
          </li>
        </ul>
      </div>
    </div>
  </section>
  <!-- Banner -->
 

  <!-- Blog -->
<section class="blog-section overflow-hidden pb-100 pt-100">
    <div class="container">
        <div class="row gy-5">
            <div class="col-lg-8">
                <div class="blog__item blog__item-details">
                    <div class="blog__item-img">
                        <img src="<?php echo e(asset('assets/images/'.$blog->photo)); ?>" alt="blog"><span class="date">
                            <span> <?php echo e($blog->created_at->format('F')); ?> </span>
                            <span><?php echo e($blog->created_at->format('d')); ?></span>
                        </span>
                    </div>
                    <div class="blog__item-cont">
                        <div class="blog__author mb-4 mt-3">
                            <div class="author w-auto">
                                <img src="<?php echo e(asset('assets/images/'.$blog->photo)); ?>" alt="blog">
                                <h6><?php echo app('translator')->get('By Admin'); ?></h6>
                            </div>
                            <a href="#0" class="text--base"><?php echo e($blog->views); ?> <?php echo app('translator')->get('Views'); ?></a>
                        </div>
                        <div class="blog__details">
                            <h5 class="subtitle">
                               <?php echo e($blog->title); ?>

                            </h5>
                            <p>
                                <?php echo $blog->details; ?>

                            </p>
                            <div class="d-flex align-items-center flex-wrap">
                                <h6 class="m-0 me-2 align-items-center"><?php echo app('translator')->get('Share Now'); ?></h6>
                                <ul class="social-icons social-icons-dark">
                                    <li>
                                        <a class="a2a_dd plus" href="https://www.addtoany.com/share">
                                            <i class="fas fa-plus"></i>
                                            </a>
                                    </li>
                                     <script async src="https://static.addtoany.com/menu/page.js"></script>
                                    
                                        <?php if($gs->is_disqus == 1): ?>
                                        <div class="comments">
                                            <div id="disqus_thread">
                                                <script>
                                                    (function() {
                                                    var d = document, s = d.createElement('script');
                                                    s.src = 'https://<?php echo e($gs->disqus); ?>.disqus.com/embed.js';
                                                    s.setAttribute('data-timestamp', +new Date());
                                                    (d.head || d.body).appendChild(s);
                                                    })();
                                                </script>
                                                <noscript><?php echo e(__('Please enable JavaScript to view the')); ?> <a href="https://disqus.com/?ref_noscript"><?php echo e(__('comments powered by Disqus.')); ?></a></noscript>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <aside class="blog-sidebar ps-xxl-5">
                    <div class="widget bg--section">
                        <div class="widget-header text-center">
                            <h5 class="m-0 text-white"><?php echo app('translator')->get('Latest Blog Posts'); ?></h5>
                        </div>
                        <div class="widget-body">
                            <ul class="latest-posts">

                                 <?php $__currentLoopData = $latest_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lblog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                 <li>
                                    <a href="<?php echo e(route('front.blog.single',$blog->slug)); ?>">
                                        <div class="img">
                                            <img src="<?php echo e(asset('assets/images/'.$lblog->photo)); ?>" alt="blog">
                                        </div>
                                        <div class="cont">
                                            <h5 class="subtitle"><?php echo e($lblog->title); ?></h5>
                                            <span class="date"><?php echo e($lblog->created_at->format('Y-m-d')); ?></span>
                                        </div>
                                    </a>
                                </li>
                                     
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                             
                            </ul>
                        </div>
                    </div>
                    <div class="widget bg--section">
                        <div class="widget-header text-center">
                            <h5 class="m-0 text-white"><?php echo app('translator')->get('Category'); ?></h5>
                        </div>
                        <div class="widget-body">
                            <ul class="archive-links">

                                <?php $__currentLoopData = $blog_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li>
                                    <a href="<?php echo e(route('front.blogcategory',$cat->slug)); ?>">
                                        <span><?php echo e($cat->name); ?></span>
                                        <span>(<?php echo e(DB::table('blogs')->where('category_id',$cat->id)->count()); ?>)</span>
                                    </a>
                                </li>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                
                            </ul>
                        </div>
                    </div>
                    
                    <div class="widget bg--section">
                        <div class="widget-header text-center">
                            <h5 class="m-0 text-white"><?php echo app('translator')->get('Tags'); ?></h5>
                        </div>
                        <div class="widget-body">
                            <ul class="widget-tags">
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('front.blogtags',$tag)); ?>">
                                       <?php echo e($tag); ?>

                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                
                            </ul>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    </div>
</section>
<!-- Blog -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/front/single_blog.blade.php ENDPATH**/ ?>