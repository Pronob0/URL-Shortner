<?php $__env->startSection('content'); ?>

<div class="card">
	<div class="d-sm-flex align-items-center justify-content-between">
	<h5 class=" mb-0 text-gray-800 pl-3"><?php echo e(__('Customer Review')); ?></h5>
	<ol class="breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.ps.review')); ?>"><?php echo e(__('Customer Review')); ?></a></li>
	</ol>
	</div>
</div>


<!-- Row -->
<div class="row mt-3">
  <!-- Datatables -->
  <div class="col-lg-12">

	<?php echo $__env->make('includes.admin.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="card mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
          <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Customer Review')); ?></h6>
        </div>

        <div class="card-body">
          <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
          <form action="<?php echo e(route('admin.ps.update')); ?>" method="POST" enctype="multipart/form-data">
              <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

              <?php echo e(csrf_field()); ?>


              <div class="form-group">
                  <label for="title"><?php echo e(__('Review Section Title')); ?> *</label>
                  <input type="text" class="form-control" id="title" name="review_title"  placeholder="<?php echo e(__('Title Here.....')); ?>" value="<?php echo e($ps->review_title); ?>" required>
              </div>

              <div class="form-group">
                <label for="text"><?php echo e(__('Review Section Text')); ?> *</label>
                <textarea name="review_text" id="text" cols="30" rows="5" class="form-control summernote" placeholder="<?php echo e(__('Review Text')); ?>" required><?php echo e($ps->review_text); ?> </textarea>
              </div>

              <button type="submit" class="btn btn-primary btn-block"><?php echo e(__('Submit')); ?></button>

          </form>
        </div>
      </div>

	<div class="card mb-4">
	  <div class="table-responsive p-3">
		<table id="geniustable" class="table table-hover dt-responsive" cellspacing="0" width="100%">
		  <thead class="thead-light">
			<tr>
                <th><?php echo e(__('Featured Image')); ?></th>
                <th><?php echo e(__('Title')); ?></th>
                <th><?php echo e(__('Details')); ?></th>\
                <th><?php echo e(__('Ratings')); ?></th>
                <th><?php echo e(__('Options')); ?></th>
			</tr>
		  </thead>
		</table>
	  </div>
	</div>
  </div>
  <!-- DataTable with Hover -->

</div>
<!--Row-->



<div class="modal fade confirm-modal" id="statusModal" tabindex="-1" role="dialog"
	aria-labelledby="statusModalTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
	<div class="modal-content">
		<div class="modal-header">
		<h5 class="modal-title"><?php echo e(__("Update Status")); ?></h5>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
		</div>
		<div class="modal-body">
			<p class="text-center"><?php echo e(__("You are about to change the status.")); ?></p>
			<p class="text-center"><?php echo e(__("Do you want to proceed?")); ?></p>
		</div>
		<div class="modal-footer">
		<a href="javascript:;" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__("Cancel")); ?></a>
		<a href="javascript:;" class="btn btn-success btn-ok"><?php echo e(__("Update")); ?></a>
		</div>
	</div>
	</div>
</div>






<div class="modal fade confirm-modal" id="deleteModal" tabindex="-1" role="dialog"
aria-labelledby="deleteModalTitle" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title"><?php echo e(__("Confirm Delete")); ?></h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
	<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
	<p class="text-center"><?php echo e(__("You are about to delete this Blog.")); ?></p>
	<p class="text-center"><?php echo e(__("Do you want to proceed?")); ?></p>
</div>
<div class="modal-footer">
	<a href="javascript:;" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__("Cancel")); ?></a>
	<a href="javascript:;" class="btn btn-danger btn-ok"><?php echo e(__("Delete")); ?></a>
</div>
</div>
</div>
</div>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>




    <script type="text/javascript">
	"use strict";

		var table = $('#geniustable').DataTable({
			   ordering: false,
               processing: true,
               serverSide: true,
               searching: false,
               ajax: '<?php echo e(route('admin.rating.datatables')); ?>',
               columns: [

                        { data: 'photo', name: 'photo' , searchable: false, orderable: false},
                        { data: 'name', name: 'name' },
                        { data: 'details', name: 'details' },
                        { data: 'rating', name: 'rating' },
            			{ data: 'action', searchable: false, orderable: false }

                     ],
                language : {
                	processing: '<img src="<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>">'
                }
            });

			$(function() {
            $(".btn-area").append('<div class="col-sm-12 col-md-4 pr-3 text-right">'+
                '<a class="btn btn-primary" href="<?php echo e(route('admin.rating.create')); ?>">'+
            '<i class="fas fa-plus"></i> Add New Client'+
            '</a>'+
            '</div>');
        });






</script>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\newfolder\main_file\project\resources\views/admin/pagesetting/review.blade.php ENDPATH**/ ?>