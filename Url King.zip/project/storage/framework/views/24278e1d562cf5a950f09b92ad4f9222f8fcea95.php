<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="d-sm-flex align-items-center justify-content-between">
  <h5 class=" mb-0 text-gray-800 pl-3"><?php echo e(__('Edit Plan')); ?> <a class="btn btn-primary btn-rounded btn-sm" href="<?php echo e(route('admin.subscription.index')); ?>"><i class="fas fa-arrow-left"></i> <?php echo e(__('Back')); ?></a></h5>
  <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>

      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.subscription.index')); ?>"><?php echo e(__('Subscription Plan')); ?></a></li>
      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.subscription.edit',$subscription->slug)); ?>"><?php echo e(__('Edit Plan')); ?></a></li>
  </ol>
  </div>
</div>

<div class="row justify-content-center mt-3">
<div class="col-lg-6">
  <!-- Form Basic -->
  <div class="card mb-4">
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
      <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Edit Subscription Plan Form')); ?></h6>
    </div>

    <div class="card-body">
      <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
      <form class="geniusform" action="<?php echo e(route('admin.subscription.update',$subscription->id)); ?>" method="POST" >
        <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


          <?php echo e(csrf_field()); ?>


          <div class="form-group">
            <label for="title"><?php echo e(__('Name')); ?></label>
            <input type="text" class="form-control" id="title" name="title"  placeholder="<?php echo e(__('Enter Title')); ?>" value="<?php echo e($subscription->title); ?>" required>
         </div>
         <div class="form-group">
            <label for="slug"><?php echo e(__('Slug')); ?></label>
            <input type="text" class="form-control" id="slug" name="slug"  placeholder="<?php echo e(__('Enter Slug')); ?>" value="<?php echo e($subscription->slug); ?>" required>
         </div>

         <div class="form-group">
            <label for="trial_days"><?php echo e(__('Days')); ?></label>
            <input type="text" class="form-control" name="days" min="1"  placeholder="<?php echo e(__('Enter Trial Days')); ?>" value="<?php echo e($subscription->days); ?>" required>
         </div>
         <div class="form-group">
            <label for="price"><?php echo e(__('Price')); ?></label>
            <input type="text" class="form-control" name="price" min="0"  placeholder="<?php echo e(__('Enter Price')); ?>" value="<?php echo e($subscription->price); ?>" required>
         </div>

         <div class="form-group">
            <label for="allowed_url"><?php echo e(__('Allowed Links')); ?></label>
            <input type="number" class="form-control"  name="allowed_url" min="1"  placeholder="<?php echo e(__('Limit URl for this plan')); ?>" value="<?php echo e($subscription->allowed_url); ?>" required min="1">
         </div>
         <div class="form-group">
            <label for="allowed_url"><?php echo e(__('Limit Click')); ?></label>
            <input type="number" class="form-control"  name="click_limit" min="1"  placeholder="<?php echo e(__('Limit URl for this plan')); ?>" value="<?php echo e($subscription->click_limit); ?>" required min="1">
         </div>

         <div class="form-group">
          <label for="allowed_url"><?php echo e(__('Link Expired Limit')); ?> <small><?php echo e(__('In days')); ?></small></label>
          <input type="number" class="form-control"  name="expired_limit" min="1"  placeholder="<?php echo e(__('Link Expired Limit')); ?>" value="<?php echo e($subscription->expired_limit); ?>" required >
       </div>

         <div class="form-group">
            <label for="details"><?php echo e(__('Details')); ?></label>
            <textarea type="text" class="form-control" name="details"   placeholder="<?php echo e(__('Enter Details')); ?>" value="" ><?php echo e($subscription->details); ?></textarea>
         </div>

        </div>


          <button type="submit" id="submit-btn" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>

      </form>
    </div>
  </div>

  <!-- Form Sizing -->

  <!-- Horizontal Form -->

</div>

</div>
<!--Row-->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
'use strict';
$("#seo").change(function() {
    if(this.checked) {
        $('.showbox').removeClass('d-none');
    }else{
        $('.showbox').addClass('d-none');
    }
});

$("#title").keyup(function() {
  var Text = $(this).val();
  Text = Text.toLowerCase();
  Text = Text.replace(/[^a-zA-Z0-9]+/g,'-');
  $("#slug").val(Text);
});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/admin/subscription/edit.blade.php ENDPATH**/ ?>