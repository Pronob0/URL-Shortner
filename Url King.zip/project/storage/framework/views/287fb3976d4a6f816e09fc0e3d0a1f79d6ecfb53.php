

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- Banner -->
<section class="hero-section inner-hero">
    <div class="container">
      <div class="inner-hero-text">
        <h2 class="title"><?php echo app('translator')->get('Blogs'); ?></h2>
        <ul class="breadcrumb">
          <li>
            <a href="index.html"><?php echo app('translator')->get('Home'); ?></a>
          </li>
          <li>
            <?php echo app('translator')->get('Blogs'); ?>
          </li>
        </ul>
      </div>
    </div>
  </section>
  <!-- Banner -->
 

    <!-- Blog -->
    <section class="blog-section overflow-hidden pb-100 pt-100">
        <div class="container">
            <div class="row g-4 g-lg-3 g-xl-4 justify-content-center">

                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-10">
                    <div class="blog__item">
                        <a href="<?php echo e(route('front.blog.single',$blog->slug)); ?>" class="blog-link">&nbsp;</a>
                        <div class="blog__item-img">
                            <img src="<?php echo e(asset('assets/images/'.$blog->photo)); ?>" alt="blog">
                            <span class="date">
                                <span> <?php echo e($blog->created_at->format('F')); ?> </span>
                                <span><?php echo e($blog->created_at->format('d')); ?></span>
                            </span>
                        </div>
                        <div class="blog__item-cont">
                            <h5 class="blog__item-cont-title line--2">
                                <?php echo e($blog->title); ?>

                            </h5>
                            <p class="line--3">
                                <?php echo Str::words($blog->details, 20, ' ...'); ?>

                            </p>
                            <div class="blog__author">
                                <div class="author">
                                    <img src="<?php echo e(asset('assets/images/'.$blog->photo)); ?>" alt="blog">
                                    <h6><?php echo app('translator')->get('By Admin'); ?></h6>
                                </div>
                                <a href=""><span class="read--more"><?php echo app('translator')->get('Read More'); ?></span></a>
                                
                            </div>
                        </div>
                    </div>
                </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Blog -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\newfolder\main_file\project\resources\views/front/blogs.blade.php ENDPATH**/ ?>