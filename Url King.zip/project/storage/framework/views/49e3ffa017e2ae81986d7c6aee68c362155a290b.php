

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<article class="main--content">
    <div class="dashboard-header position-relative">
<div class="bg--gradient">&nbsp;</div>

<?php if ($__env->exists('partials.user.top-nav')) echo $__env->make('partials.user.top-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="breadcrumb-area">
    <h3 class="title text--white"><?php echo app('translator')->get('Expired Links'); ?></h3>
    <ul class="breadcrumb">
        <li>
            <a href="<?php echo e(route('user.dashboard')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a>
        </li>
        <li>
            <?php echo app('translator')->get('Expired URL'); ?>
        </li>
    </ul>
</div>
</div>

<div class="dashborad--content">
    <div class="dashboard--content-item">
        <h5 class="dashboard-title"><?php echo app('translator')->get('Link List'); ?></h5>
        <div class="table--mobile-lg">
            <table class="table bg--body " id="link-table">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('Alias'); ?></th>
                        <th><?php echo app('translator')->get('URLs'); ?></th>
                        <th><?php echo app('translator')->get('Total Click'); ?></th>
                        <th><?php echo app('translator')->get('Plan'); ?></th>
                        <th><?php echo app('translator')->get('Status'); ?></th>
                        <th><?php echo app('translator')->get('Expire'); ?></th>
                        <th><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                </thead>
                <tbody id="link-table">
                    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if(checkexpire($link->id)=='Expired'): ?>     
                    <tr>
                        <td data-label="Payment Method">
                            <div>
                                <?php echo e($link->alias); ?>

                            </div>
                        </td>
                        <td data-label="Payment Method">
                            <div>
                               <a href="<?php echo e($link->url); ?>" class="btn btn--primary btn-sm"> <i class="fas fa-link"></i> </a>
                               <a id="copy-user" href="javascript:;" class="btn btn--success btn-sm" data-value="<?php echo e($link->alias); ?>"> <i class="fas fa-copy"></i> </a>
                            </div>
                        </td>
                        <td data-label="Rate">
                            <div>
                                <?php echo e($link->click); ?>

                            </div>
                        </td>
                        <td data-label="Limits">
                            <div>
                                <?php if($link->planid==0): ?>{
                                    <span class="badge btn--warning btn-sm"><?php echo app('translator')->get('Free'); ?></span>
                                }
                                <?php else: ?>
                                <span class="badge btn--primary btn-sm"><?php echo app('translator')->get('Premium'); ?></span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td data-label="Status">

                           
                             <div class="dropdown btn-group mb-1">
                                <button type="button" id="dropdown" class="btn btn--<?php echo e($link->status == 1 ? 'danger'   : 'success'); ?> btn-sm btn-rounded dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                 <?php echo e($link->status == 1 ? __('Deactive') : __('Active')); ?>

                                </button>
                                <div class="dropdown-menu" x-placement="bottom-start" aria-labelledby="dropdown">
                                  <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#statusModal" class="dropdown-item" data-href=" <?php echo e(route('user.link.status',['id1' => $link->id, 'id2' => 0])); ?>"><?php echo app('translator')->get("Active"); ?></a>

                                  <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#statusModal" class="dropdown-item" data-href="<?php echo e(route('user.link.status',['id1' => $link->id, 'id2' => 1])); ?>"><?php echo app('translator')->get("Deactive"); ?></a>
                                </div>
                              </div> 
                        </td>
                       

                        <td data-label="Payment Method">
                            <div>
                               
                                <button class="btn btn--danger btn-sm"><?php echo app('translator')->get('Expired'); ?></button>

                               
                               
                            </div>
                        </td>

                        <td data-label="Actions">
                            <div class="dropdown btn-group mb-1">
                               <button type="button" id="dropdown2" class="btn btn--primary btn-sm btn-rounded dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo app('translator')->get('Actions'); ?>
                               </button>
                               <div class="dropdown-menu" x-placement="bottom-start" aria-labelledby="dropdown2">
                                 <a href=" <?php echo e(route('user.link.edit',$link->id)); ?>"class="dropdown-item"><?php echo app('translator')->get("Edit"); ?></a>
                                 
                                 <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#deleteModal" class="dropdown-item" data-href="<?php echo e(route('user.link.delete',$link->id)); ?>"><?php echo app('translator')->get("Delete"); ?></a>
                               </div>
                             </div> 
                       </td>
                    </tr> 
                    <?php else: ?>
                          
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="footer-copyright text-center mt-auto">
        <?php echo $gs->copyright; ?>

    </div>
</div>
</article>




<div class="modal fade confirm-modal" id="statusModal" tabindex="-1" role="dialog"
aria-labelledby="statusModalTitle" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
<div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title text-center"><?php echo e(__("Update Status")); ?></h5>
    <button type="button" class="close btn btn--danger" data-bs-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>
    <div class="modal-body">
        <p class="text-center"><?php echo e(__("You are about to change the status.")); ?></p>
        <p class="text-center"><?php echo e(__("Do you want to proceed?")); ?></p>
    </div>
    <div class="modal-footer">
    <a href="javascript:;" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__("Cancel")); ?></a>
    <a href="javascript:;" class="btn btn-success btn-ok"><?php echo e(__("Update")); ?></a>
    </div>
</div>
</div>
</div>





<div class="modal fade confirm-modal" id="deleteModal" tabindex="-1" role="dialog"
aria-labelledby="statusModalTitle" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
<div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title text-center"><?php echo e(__("Delete Link")); ?></h5>
    <button type="button" class="close btn btn--danger" data-bs-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>
    <div class="modal-body">
        <p class="text-center"><?php echo e(__("You are about to delete this Link.")); ?></p>
        <p class="text-center"><?php echo e(__("Do you want to proceed?")); ?></p>
    </div>
    <div class="modal-footer">
    <a href="javascript:;" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__("Cancel")); ?></a>
    <a href="javascript:;" class="btn btn--danger btn-ok"><?php echo e(__("Delete")); ?></a>
    </div>
</div>
</div>
</div>






<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/user/link/expired-link.blade.php ENDPATH**/ ?>