<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="d-sm-flex align-items-center justify-content-between">
    <h5 class=" mb-0 text-gray-800 pl-3"><?php echo e(__('Add New Role')); ?> <a class="btn btn-primary btn-rounded btn-sm" href="<?php echo e(route('admin.role.index')); ?>"><i class="fas fa-arrow-left"></i> <?php echo e(__('Back')); ?></a></h5>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
        <li class="breadcrumb-item"><a href="javascript:;"><?php echo e(__('Roles')); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.role.index')); ?>"><?php echo e(__('Manage Roles')); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.role.create')); ?>"><?php echo e(__('Add New Role')); ?></a></li>
    </ol>
    </div>
</div>

<div class="row justify-content-center mt-3">
  <div class="col-lg-6">
    <!-- Form Basic -->
    <div class="card mb-4">
      <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
        <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__('Add Role Form')); ?></h6>
      </div>

      <div class="card-body">
        <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
        <form class="geniusform" action="<?php echo e(route('admin.role.store')); ?>" method="POST" enctype="multipart/form-data">

            <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo e(csrf_field()); ?>


          <div class="form-group">
              <label for="inp-name"><?php echo e(__('Role Name')); ?></label>
              <input type="text" class="form-control" id="inp-name" name="name"  placeholder="<?php echo e(__('Enter Role Name')); ?>" value="" required>
          </div>

          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Manage Categories" class="custom-control-input" id="manage_category">
                  <label class="custom-control-label" for="manage_category"><?php echo e(__('Manage Categories')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Manage Orders" class="custom-control-input" id="manage_order">
                  <label class="custom-control-label" for="manage_order"><?php echo e(__('Manage Orders')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Manage Products" class="custom-control-input" id="manage_products">
                  <label class="custom-control-label" for="manage_products"><?php echo e(__('Manage Products')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Author Level" class="custom-control-input" id="author_level">
                  <label class="custom-control-label" for="author_level"><?php echo e(__('Author Level')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="General Setting" class="custom-control-input" id="general_setting">
                  <label class="custom-control-label" for="general_setting"><?php echo e(__('General Setting')); ?></label>
                  </div>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Homepage Setting" class="custom-control-input" id="homepage_setting">
                  <label class="custom-control-label" for="homepage_setting"><?php echo e(__('Homepage Setting')); ?></label>
                  </div>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Email Setting" class="custom-control-input" id="email_setting">
                  <label class="custom-control-label" for="email_setting"><?php echo e(__('Email Setting')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Users" class="custom-control-input" id="user">
                  <label class="custom-control-label" for="user"><?php echo e(__('Users')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Manage Roles" class="custom-control-input" id="manage_roles">
                  <label class="custom-control-label" for="manage_roles"><?php echo e(__('Manage Roles')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Messages" class="custom-control-input" id="message">
                  <label class="custom-control-label" for="message"><?php echo e(__('Messages')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Manage Blog" class="custom-control-input" id="manage_blog">
                  <label class="custom-control-label" for="manage_blog"><?php echo e(__('Manage Blog')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Menupage Setting" class="custom-control-input" id="menupage_setting">
                  <label class="custom-control-label" for="menupage_setting"><?php echo e(__('Menupage Setting')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Social Setting" class="custom-control-input" id="social_setting">
                  <label class="custom-control-label" for="social_setting"><?php echo e(__('Social Settings')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Seo Tools" class="custom-control-input" id="seo_tools">
                  <label class="custom-control-label" for="seo_tools"><?php echo e(__('Seo Tools')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Payment Setting" class="custom-control-input" id="payment_setting">
                  <label class="custom-control-label" for="payment_setting"><?php echo e(__('Payment Setting')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Manage Staff" class="custom-control-input" id="staff">
                  <label class="custom-control-label" for="staff"><?php echo e(__('Manage Staff')); ?></label>
                  </div>
              </div>
            </div>


            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Language Setting" class="custom-control-input" id="language_setting">
                  <label class="custom-control-label" for="language_setting"><?php echo e(__('Language Setting')); ?></label>
                  </div>
              </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                  <div class="custom-control custom-switch">
                    <input type="checkbox" name="section[]" value="Fonts" class="custom-control-input" id="font">
                    <label class="custom-control-label" for="font"><?php echo e(__('Fonts')); ?></label>
                    </div>
                </div>
              </div>
            <div class="col-md-6">
              <div class="form-group">
                <div class="custom-control custom-switch">
                  <input type="checkbox" name="section[]" value="Subscribers" class="custom-control-input" id="subscribers">
                  <label class="custom-control-label" for="subscribers"><?php echo e(__('Subscribers')); ?></label>
                  </div>
              </div>
            </div>
          </div>
          <hr>

            <button type="submit" id="submit-btn" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>

        </form>
      </div>
    </div>

    <!-- Form Sizing -->

    <!-- Horizontal Form -->

  </div>

</div>
<!--Row-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/admin/role/create.blade.php ENDPATH**/ ?>