

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<!-- Banner -->
<section class="hero-section inner-hero">
    <div class="container">
      <div class="inner-hero-text">
        <h2 class="title"><?php echo app('translator')->get('Error'); ?></h2>
        <ul class="breadcrumb">
          <li>
            <a href="index.html"><?php echo app('translator')->get('Home'); ?></a>
          </li>
          <li>
            <?php echo app('translator')->get('Error'); ?>
          </li>
        </ul>
      </div>
    </div>
  </section>
  <!-- Banner -->

   <!--==================== Error Section Start ====================-->
   <div class="full-row" style="padding: 100px 0">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="text-center">
                    <img src="<?php echo e($gs->error_banner ? asset('assets/images/'.$gs->error_banner):asset('assets/images/noimage.png')); ?>" alt="">
                    <h2 class="my-4"><?php echo e(__('404 Page not found')); ?></h2>
                    <p><?php echo e(__('The page you are looking for dosen’t exist or another error occourd go back to home or another source')); ?></p>
                    <a class="btn btn-secondary mt-5" href="<?php echo e(route('front.index')); ?>"><?php echo e(__('Return to home')); ?></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--==================== Error Section Form Start ====================-->


 

  

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\newfolder\main_file\project\resources\views/errors/404.blade.php ENDPATH**/ ?>