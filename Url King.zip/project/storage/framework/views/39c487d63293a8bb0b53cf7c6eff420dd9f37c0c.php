

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<!-- Banner -->
<section class="hero-section inner-hero">
    <div class="container">
      <div class="inner-hero-text">
        <h2 class="title"><?php echo app('translator')->get('Forgot Password'); ?></h2>
        <ul class="breadcrumb">
          <li>
            <a href="index.html"><?php echo app('translator')->get('Home'); ?></a>
          </li>
          <li>
            <?php echo app('translator')->get('Forgot Password'); ?>
          </li>
        </ul>
      </div>
    </div>
  </section>
  <!-- Banner -->
  <!-- Account -->
  <section class="account-section pt-100 pb-100">
      <div class="container">
          <div class="account-wrapper bg--section">
              <div class="section-title mb-3">
                  
                  <h3 class="title"><?php echo app('translator')->get('Forgot Password'); ?></h3>
              </div>

              <form class="account-form row gy-3 gx-4 align-items-center" id="forgotform" action="<?php echo e(route('user.forgot.submit')); ?>" method="POST">
             
                <div class="alert alert-info validation" style="display: none;">
                    <p class="text-left"></p>
                </div>
                <?php echo csrf_field(); ?>
                  <div class="col-sm-12">
                      <label for="email" class="form-label"><?php echo app('translator')->get('Your Email'); ?></label>
                      <input type="text" id="email" id="reg_email" name="email" class="form-control form--control">
                  </div>
                 <p><?php echo app('translator')->get('A password will be sent to your email address.'); ?></p>
                  <div class="col-sm-12">
                    <input id="authdata" type="hidden" value="<?php echo e(__('Checking...')); ?>">
                      <button type="submit" name="register" id="btn" class="cmn--btn bg--base me-3 submit-btn">
                          <?php echo app('translator')->get('Submit'); ?>
                      </button>
                     
                  </div>
              </form>
          </div>
      </div>
  </section>
  <!-- Account -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/front/forgot.blade.php ENDPATH**/ ?>