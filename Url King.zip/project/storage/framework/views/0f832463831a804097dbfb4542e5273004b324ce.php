<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="d-sm-flex align-items-center justify-content-between">
      <h5 class=" mb-0 text-gray-800 pl-3"><?php echo e(__('Add Font')); ?> <a class="btn btn-primary btn-rounded btn-sm" href="<?php echo e(route('admin.font.index')); ?>"><i class="fas fa-arrow-left"></i> <?php echo e(__('Back')); ?></a></h5>
      <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
          <li class="breadcrumb-item"><a href="javascript:;"><?php echo e(__('Font Settings')); ?></a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('admin.font.index')); ?>"><?php echo e(__('Website Font')); ?></a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('admin.font.create')); ?>"><?php echo e(__('Add Font')); ?></a></li>
      </ol>
    </div>
</div>

<div class="row justify-content-center mt-3">
  <div class="col-lg-12">
    <!-- Form Basic -->
    <div class="card mb-4">
      <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
      </div>

      <div class="card-body">

        <form class="geniusform" action="<?php echo e(route('admin.font.store')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="row">
            <div class="col-lg-4">
              <div class="left-area">
                  <h6 class="heading float-right"><?php echo e(__('Font Family')); ?> *</h6>
              </div>
            </div>
            <div class="col-lg-7">
              <input type="text" class="input-field" name="font_family" placeholder="<?php echo e(__('Font Family')); ?>" required="">
            </div>
          </div>


          <div class="row justify-content-center mt-4">
            <button type="submit" id="submit-btn" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
          </div>
        </form>
      </div>
    </div>

    <!-- Form Sizing -->

    <!-- Horizontal Form -->

  </div>
</div>
<!--Row-->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
  <script type="text/javascript">


  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/admin/font/create.blade.php ENDPATH**/ ?>