
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<!-- User Dashboard -->


    <article class="main--content">
        <div class="dashboard-header position-relative">
    <div class="bg--gradient">&nbsp;</div>
    <?php if ($__env->exists('partials.user.top-nav')) echo $__env->make('partials.user.top-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="breadcrumb-area">
        <h3 class="title text--white"><?php echo app('translator')->get('Two Factor'); ?></h3>
        <ul class="breadcrumb">
            <li>
                <a href="<?php echo e(route('user.dashboard')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a>
            </li>
            <li>
                <?php echo app('translator')->get('Two Factor'); ?>
            </li>
        </ul>
    </div>
</div>


        <div class="dashborad--content">
            <div class="dashboard--content-item">

                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <?php if(Auth::user()->twofa): ?>
                            <div class="card default--card">
                                <div class="card-header">
                                    
                                </div>
                                <div class="card-body">
                                    <div class="form-group mx-auto text-center">
                                        <a href="javascript:void(0)"  class="btn w-100 btn-md btn--danger" data-bs-toggle="modal" data-bs-target="#disableModal">
                                            <?php echo app('translator')->get('Disable Two Factor Authenticator'); ?></a>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="card default--card">
                                <div class="card-header">
                                    <h5 class="card-title text-dark text-center pt-3"><?php echo app('translator')->get('Two Factor Authenticator'); ?></h5>
                                </div>
                                <div class="card-body">
                                    <div class="form-group mx-auto text-center">
                                        <div class="input-group input--group">
                                            <input type="text" name="key" value="<?php echo e($secret); ?>" class="form-control bg--section" id="referralURL" readonly>
                                            <button class="btn input-group-text btn--secondary btn-sm copytext px-4" id="copyBoard" onclick="myFunction()"> <i class="fa fa-copy"></i> </button>
                                        </div>
                                    </div>
                                    <div class="form-group mx-auto text-center mt-3">
                                        <img class="mx-auto" src="<?php echo e($qrCodeUrl); ?>">
                                    </div>
                                    <div class="form-group mx-auto text-center">
                                        <a href="javascript:void(0)" class="btn btn--base btn-md mt-3 mb-1" data-bs-toggle="modal" data-bs-target="#enableModal"><?php echo app('translator')->get('Enable Two Factor Authenticator'); ?></a>
                                    </div> 
            
                                    <div class="form-group mx-auto text-center">
                                        <a class="btn btn--base btn-md mt-3" href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en" target="_blank"><?php echo app('translator')->get('DOWNLOAD APP'); ?></a>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
            </div>
            <div class="footer-copyright text-center mt-auto">
               <?php echo $gs->copyright; ?>

            </div>
        </div>
    </article>

<!-- User Dashboard -->

<div id="enableModal" class="modal modal-blur fade" role="dialog" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog ">
        <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo app('translator')->get('Verify Your Otp'); ?></h4>
            </div>
            <form action="<?php echo e(route('user.createTwoFactor')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body ">
                    <div class="form-group">
                        <input type="hidden" name="key" value="<?php echo e($secret); ?>">
                        <input type="text" class="form-control" name="code" placeholder="<?php echo app('translator')->get('Enter Google Authenticator Code'); ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal"><?php echo app('translator')->get('close'); ?></button>
                    <button type="submit" class="btn btn-success"><?php echo app('translator')->get('verify'); ?></button>
                </div>
            </form>
        </div>

    </div>
</div>

 <!--Disable Modal -->
 <div id="disableModal" class="modal modal-blur fade" role="dialog" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><?php echo app('translator')->get('Verify Your Otp Disable'); ?></h4>
                <button type="button" class="close btn btn--danger " data-bs-dismiss="modal">&times;</button>
            </div>
            <form action="<?php echo e(route('user.disableTwoFactor')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" name="code" placeholder="<?php echo app('translator')->get('Enter Google Authenticator Code'); ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger " data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn-success"><?php echo app('translator')->get('Verify'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    "use strict";
    function myFunction() {
        var copyText = document.getElementById("referralURL");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        document.execCommand("copy");
        toastr.success('Two factor authentication code copied');
     
    }

    <?php if(Session::has('success')): ?>
  toastr.options =
  {
  	"closeButton" : true,
  	"progressBar" : true
  }
  		toastr.success("<?php echo e(session('success')); ?>");
  <?php endif; ?>


</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/user/twofactor/index.blade.php ENDPATH**/ ?>