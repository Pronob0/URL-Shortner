<?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="d-sm-flex align-items-center justify-content-between">
    <h5 class=" mb-0 text-gray-800 pl-3"><?php echo e(__('Facebook Login')); ?></h5>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
        <li class="breadcrumb-item"><a href="javascript:;"><?php echo e(__('Social Links')); ?></a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.social.facebook')); ?>"><?php echo e(__('Facebook Login')); ?></a></li>
    </ol>
    </div>
  </div>

  <div class="row justify-content-center mt-3">
    <div class="col-lg-6">
      <!-- Form Basic -->
      <div class="card mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
        </div>

        <div class="card-body">
          <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
          <form class="geniusform" action="<?php echo e(route('admin.social.update')); ?>" method="POST" enctype="multipart/form-data">

              <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

              <?php echo e(csrf_field()); ?>


              <div class="form-group">
                <label for="inp-title"><?php echo e(__('Facebook Login')); ?> </label>
                <div class="frm-btn btn-group mb-1">
                    <button type="button" class="btn btn-sm btn-rounded dropdown-toggle btn-<?php echo e($data->f_check == 1 ? 'success' : 'danger'); ?>" data-toggle="dropdown"
                      aria-haspopup="true" aria-expanded="false">
                      <?php echo e($data->f_check == 1 ? __('Activated') : __('Deactivated')); ?>

                    </button>
                    <div class="dropdown-menu">
                      <a class="dropdown-item drop-change" href="javascript:;" data-status="1" data-val="<?php echo e(__('Activated')); ?>" data-href="<?php echo e(route('admin.social.facebookup',1)); ?>"><?php echo e(__('Activate')); ?></a>
                      <a class="dropdown-item drop-change" href="javascript:;" data-status="0" data-val="<?php echo e(__('Deactivated')); ?>" data-href="<?php echo e(route('admin.social.facebookup',0)); ?>"><?php echo e(__('Deactivate')); ?></a>
                    </div>
                  </div>
            </div>

              <div class="form-group">
                <label for="inp-name"><?php echo e(__('App ID')); ?> *</label>
                <small><?php echo e(__('(Get Your App ID from developers.facebook.com)')); ?></small>
                <input type="text" class="input-field" placeholder="<?php echo e(__('Enter App ID')); ?>" name="fclient_id" value="<?php echo e($data->fclient_id); ?>" required="">
              </div>

              <div class="form-group">
                <label for="inp-name"><?php echo e(__('App Secret')); ?> *</label>
                <small><?php echo e(__('(Get Your App Secret from developers.facebook.com)')); ?></small>
                <input type="text" class="input-field" placeholder="<?php echo e(__('Enter App Secret')); ?>" name="fclient_secret" value="<?php echo e($data->fclient_secret); ?>" required="">
              </div>

              <div class="form-group">
                <label for="inp-name"><?php echo e(__('Website URL')); ?> *</label>
                <input type="text" class="input-field" placeholder="<?php echo e(__('Website URL')); ?>"  value="<?php echo e(url('/')); ?>" readonly="">
              </div>

              <div class="form-group">
                <label for="inp-name"><?php echo e(__('Valid OAuth Redirect URI')); ?> *</label>
                <small><?php echo e(__('(Copy this url and paste it to your Valid OAuth Redirect URI in developers.facebook.com.)')); ?></small>
                <?php
                $url = url('/auth/facebook/callback');
                $url = preg_replace("/^http:/i", "https:", $url);
                ?>
                <input type="text" class="input-field" placeholder="<?php echo e(__('Enter Site URL')); ?>" name="fredirect" value="<?php echo e($url); ?>" readonly>
              </div>
              <button type="submit" id="submit-btn" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
          </form>
        </div>
      </div>

      <!-- Form Sizing -->


      <!-- Horizontal Form -->

    </div>


  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\newfolder\main_file\project\resources\views/admin/socialsetting/facebook.blade.php ENDPATH**/ ?>