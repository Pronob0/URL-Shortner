<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<!-- Banner -->
<section class="hero-section inner-hero">
    <div class="container">
      <div class="inner-hero-text">
        <h2 class="title"><?php echo app('translator')->get('Login'); ?></h2>
        <ul class="breadcrumb">
          <li>
            <a href="index.html"><?php echo app('translator')->get('Home'); ?></a>
          </li>
          <li>
            <?php echo app('translator')->get('Login'); ?>
          </li>
        </ul>
      </div>
    </div>
  </section>
  <!-- Banner -->
  <!-- Account -->
  <section class="account-section pt-100 pb-100">
      <div class="container">
          <div class="account-wrapper bg--section">
              <div class="section-title mb-3">
                  <h6 class="subtitle mb-3 text--base"><?php echo app('translator')->get('Sign In'); ?></h6>
                  <h3 class="title"><?php echo app('translator')->get('Login Now'); ?></h3>
              </div>

              <form class="account-form row gy-3 gx-4 align-items-center" id="loginform" action="<?php echo e(route('user.login.submit')); ?>" method="POST">
                <?php if ($__env->exists('alerts.form-login')) echo $__env->make('alerts.form-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo csrf_field(); ?>
                  <div class="col-sm-12">
                      <label for="email" class="form-label"><?php echo app('translator')->get('Your Email'); ?></label>
                      <input type="text" id="email" name="email" class="form-control form--control">
                  </div>
                  <div class="col-sm-12">
                      <label for="password" class="form-label"><?php echo app('translator')->get('Your Password'); ?></label>
                      <input type="password" id="password" name="password" class="form-control form--control">
                  </div>
                  <div class="col-sm-12">
                    <input id="authdata" type="hidden" value="<?php echo e(__('Authenticating...')); ?>">
                      <button type="submit" id="btn" class="cmn--btn bg--base me-3">
                          <?php echo app('translator')->get('Login Now'); ?>
                      </button>
                      <div class="d-flex flex-wrap justify-content-between align-items-center mt-2">
                          <a href="<?php echo e(route('user.forgot')); ?>" class="text--base mt-1"><?php echo app('translator')->get('Forget Password'); ?></a>
                          <a href="registration.html" class="text--base mt-1"><?php echo app('translator')->get("Don't have
                            an account ?"); ?></a>
                      </div>
                      <?php if($socialsetting->f_check == 1 || $socialsetting->g_check == 1): ?>
                                                    <div class="social-area text-center">
                                                        <h3 class="title  mt-3"><?php echo e(('OR')); ?></h3>
                                                        <p class="text"><?php echo e(__('Sign In with social media')); ?></p>
                                                        <ul class="social-links">
                                                            <?php if($socialsetting->f_check == 1): ?>
                                                            <li>
                                                            <a href="<?php echo e(route('social-provider','facebook')); ?>">
                                                                <i class="fab fa-facebook-f"></i>
                                                            </a>
                                                            </li>
                                                            <?php endif; ?>
                                                            <?php if($socialsetting->g_check == 1): ?>
                                                            <li>
                                                            <a href="<?php echo e(route('social-provider','google')); ?>">
                                                                <i class="fab fa-google"></i>
                                                            </a>
                                                            </li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
					              <?php endif; ?>
                  </div>
              </form>
          </div>
      </div>
  </section>
  <!-- Account -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pro-short\project\resources\views/front/login.blade.php ENDPATH**/ ?>